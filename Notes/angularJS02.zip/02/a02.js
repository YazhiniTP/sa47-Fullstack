var app = angular.module('app', []);

app.controller("amp", ["$scope", MyCtrl]);

function MyCtrl($scope) {
	$scope.counter = 0;

	var ticktock = function() {
		$scope.$apply(function() {
			$scope.counter++;
		});
		setTimeout(ticktock, 1000);
	};

	setTimeout(ticktock, 1000);
}

 