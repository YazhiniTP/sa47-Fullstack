        //1. create app module 
        var memberApp = angular.module('memberApp', []);