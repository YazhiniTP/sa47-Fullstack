//2. create controller
memberApp.controller("memberController", function ($scope, $http) {

    //3. attach originalMember model object
    $scope.originalMember = {
        firstName: 'Darryl',
        surName: 'Ng Eng Soon',
        secondName: 'Eddie'
    };

    //4. copy originalMember to member. memebr will be bind to a form 
    $scope.member = angular.copy($scope.originalMember);

    //5. create submitMemberForm() function. This will be called when user submits the form
    $scope.submitMemberForm = function () {

        var onSuccess = function (data, status, headers, config) {
            alert('Member saved successfully.');
        };

        var onError = function (data, status, headers, config) {
            alert('Error occured.');
        }

        $http.post('/member/submitData', { member:$scope.member })
            .success(onSuccess)
            .error(onError);

    };

    //6. create resetForm() function. This will be called on Reset button click.  
    $scope.resetForm = function () {
        $scope.member = angular.copy($scope.originalMember);
    };
});