var express = require('express');
var app = express();
var path = require('path');

app.use(express.static(path.join(__dirname, 'public')));

// viewed at http://localhost:1337
app.get('/', function(req, res) {
    res.sendFile(path.join(__dirname + '/views/memberApp.html'));
});

app.listen(1337);

console.log("Running at Port 1337");