var app = angular.module('controllerApp', []);

app.factory('mySharedService', function($rootScope) {
    var sharedService = {};

    sharedService.sharedmessage  = '';

    sharedService.prepForPublish = function(msg) {
        this.sharedmessage  = msg;
        this.publishItem();
    };

    sharedService.publishItem = function() {
        $rootScope.$broadcast('handlePublish');
    };

    return sharedService;
});


function FirstController($scope, sharedService) {
    $scope.publish = function(msg) {
        sharedService.prepForPublish(msg);
    };

    $scope.$on('handlePublish', function() {
        $scope.sharedmessage  = sharedService.sharedmessage ;
    });
}

function SecondController($scope, sharedService) {
	$scope.publish = function(msg) {
        sharedService.prepForPublish(msg);
    };

    $scope.$on('handlePublish', function() {
        $scope.sharedmessage  = sharedService.sharedmessage ;
    });
}

function ThirdController($scope, sharedService) {
    $scope.publish = function(msg) {
        sharedService.prepForPublish(msg);
    };

    $scope.$on('handlePublish', function() {
        $scope.sharedmessage  = sharedService.sharedmessage ;
    });
}

app.controller('FirstController', ['$scope', 'mySharedService', FirstController]);

app.controller('SecondController', ['$scope', 'mySharedService', SecondController]);

app.controller('ThirdController', ['$scope', 'mySharedService', ThirdController]);


FirstController.$inject = ['$scope', 'mySharedService'];

SecondController.$inject = ['$scope', 'mySharedService'];

ThirdController.$inject = ['$scope', 'mySharedService'];