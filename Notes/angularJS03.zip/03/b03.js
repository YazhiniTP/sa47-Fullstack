var myModule = angular.module('myModule', []);

// From this point on, we'll attach everything to 'myModule'
myModule.factory('HelloWorld', function($q, $timeout) {
  var getMessages = function() {
    var deferred = $q.defer();

    $timeout(function() {
      deferred.resolve(['Hello', 'world!']);
    }, 2000);

    return deferred.promise;
  };

  return {
    getMessages: getMessages
  };
});

myModule.controller('HelloCtrl', function($scope, HelloWorld) {
    HelloWorld.getMessages().then(function(messages) {
      $scope.messages = messages;
    });
});